// DMA controller + 4 KB RAM, with a backdoor port for testbenches.
module dma_soc #(
  parameter int unsigned MEM_BYTES = 4096
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        psel,
  input  logic        penable,
  input  logic        pwrite,
  input  logic [7:0]  paddr,
  input  logic [31:0] pwdata,
  output logic [31:0] prdata,
  output logic        pready,
  output logic        irq,
  // backdoor memory access (test only)
  input  logic        bd_we,
  input  logic [31:0] bd_addr,
  input  logic [31:0] bd_wdata,
  output logic [31:0] bd_rdata
);
  localparam int unsigned WORDS = MEM_BYTES / 4;
  logic [31:0] ram [WORDS];

  logic        mem_en, mem_we;
  logic [31:0] mem_addr, mem_wdata, mem_rdata;
  logic        pslverr;

  dma_ctrl #(.MEM_BYTES(MEM_BYTES)) u_dma (
    .clk, .rst_n, .psel, .penable, .pwrite, .paddr, .pwdata,
    .prdata, .pready, .pslverr,
    .mem_en, .mem_we, .mem_addr, .mem_wdata, .mem_rdata, .irq
  );

  always_ff @(posedge clk) begin
    if (bd_we) begin
      ram[bd_addr[$clog2(WORDS)+1:2]] <= bd_wdata;
    end else if (mem_en) begin
      if (mem_we) ram[mem_addr[$clog2(WORDS)+1:2]] <= mem_wdata;
      else        mem_rdata <= ram[mem_addr[$clog2(WORDS)+1:2]];
    end
  end

  assign bd_rdata = ram[bd_addr[$clog2(WORDS)+1:2]];
endmodule
