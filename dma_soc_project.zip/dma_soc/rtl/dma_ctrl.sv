// Simple memory-to-memory DMA controller with an APB register interface.
//
// Register map (word registers, byte offsets):
//   0x00 SRC    source byte address (word aligned)
//   0x04 DST    destination byte address (word aligned)
//   0x08 LEN    number of 32-bit words to copy (1..)
//   0x0C CTRL   bit0 START (self-clearing, ignored while BUSY), bit1 IRQ_EN
//   0x10 STATUS bit0 BUSY, bit1 DONE, bit2 ERR   (read only)
//   0x14 CLEAR  write-1-to-clear: bit0 DONE, bit1 ERR
//
// A START with LEN==0, an unaligned address, or a range that leaves the
// MEM_BYTES memory sets ERR and does not touch memory.
module dma_ctrl #(
  parameter int unsigned MEM_BYTES = 4096
) (
  input  logic        clk,
  input  logic        rst_n,
  // APB slave
  input  logic        psel,
  input  logic        penable,
  input  logic        pwrite,
  input  logic [7:0]  paddr,
  input  logic [31:0] pwdata,
  output logic [31:0] prdata,
  output logic        pready,
  output logic        pslverr,
  // memory master (read data valid one cycle after a read request)
  output logic        mem_en,
  output logic        mem_we,
  output logic [31:0] mem_addr,
  output logic [31:0] mem_wdata,
  input  logic [31:0] mem_rdata,
  // interrupt
  output logic        irq
);
  typedef enum logic [1:0] {S_IDLE, S_RD, S_CAP, S_WR} state_t;
  state_t state;

  logic [31:0] src_q, dst_q, len_q;
  logic        irq_en_q, busy_q, done_q, err_q;
  logic [31:0] s_ptr, d_ptr, cnt, data_q;

  wire apb_wr = psel & penable & pwrite;

  // range check in 35 bits: addr (32b) + len*4 (34b) cannot overflow
  wire [34:0] src_end = {3'b0, src_q} + {1'b0, len_q, 2'b00};
  wire [34:0] dst_end = {3'b0, dst_q} + {1'b0, len_q, 2'b00};
  wire bad_cfg = (len_q == 0) || (src_q[1:0] != 0) || (dst_q[1:0] != 0) ||
                 (src_end > 35'(MEM_BYTES)) || (dst_end > 35'(MEM_BYTES));

  wire start_req = apb_wr && (paddr == 8'h0C) && pwdata[0] && !busy_q;

  assign pready  = 1'b1;
  assign pslverr = 1'b0;
  assign irq     = done_q & irq_en_q;

  always_comb begin
    prdata = 32'h0;
    unique case (paddr)
      8'h00: prdata = src_q;
      8'h04: prdata = dst_q;
      8'h08: prdata = len_q;
      8'h0C: prdata = {30'b0, irq_en_q, 1'b0};
      8'h10: prdata = {29'b0, err_q, done_q, busy_q};
      default: prdata = 32'h0;
    endcase
  end

  always_comb begin
    mem_en    = 1'b0;
    mem_we    = 1'b0;
    mem_addr  = s_ptr;
    mem_wdata = data_q;
    unique case (state)
      S_RD: begin mem_en = 1'b1; mem_addr = s_ptr; end
      S_WR: begin mem_en = 1'b1; mem_we = 1'b1; mem_addr = d_ptr; end
      default: ;
    endcase
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE;
      src_q <= '0; dst_q <= '0; len_q <= '0;
      irq_en_q <= 1'b0; busy_q <= 1'b0; done_q <= 1'b0; err_q <= 1'b0;
      s_ptr <= '0; d_ptr <= '0; cnt <= '0; data_q <= '0;
    end else begin
      if (apb_wr) begin
        unique case (paddr)
          8'h00: if (!busy_q) src_q <= pwdata;
          8'h04: if (!busy_q) dst_q <= pwdata;
          8'h08: if (!busy_q) len_q <= pwdata;
          8'h0C: irq_en_q <= pwdata[1];
          8'h14: begin
            if (pwdata[0]) done_q <= 1'b0;
            if (pwdata[1]) err_q  <= 1'b0;
          end
          default: ;
        endcase
      end

      unique case (state)
        S_IDLE: if (start_req) begin
          done_q <= 1'b0;
          err_q  <= 1'b0;
          if (bad_cfg) begin
            err_q <= 1'b1;
          end else begin
            busy_q <= 1'b1;
            s_ptr  <= src_q;
            d_ptr  <= dst_q;
            cnt    <= len_q;
            state  <= S_RD;
          end
        end
        S_RD:  state <= S_CAP;
        S_CAP: begin data_q <= mem_rdata; state <= S_WR; end
        S_WR: begin
          s_ptr <= s_ptr + 32'd4;
          d_ptr <= d_ptr + 32'd4;
          cnt   <= cnt - 32'd1;
          if (cnt == 32'd1) begin
            busy_q <= 1'b0;
            done_q <= 1'b1;
            state  <= S_IDLE;
          end else begin
            state <= S_RD;
          end
        end
        default: state <= S_IDLE;
      endcase
    end
  end
endmodule
