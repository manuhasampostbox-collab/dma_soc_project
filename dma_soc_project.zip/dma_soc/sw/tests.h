// Platform-independent tests: written once, run on every Platform.
#pragma once
#include "platform.h"
#include <cstdio>
#include <cstdint>
#include <random>

struct Result { int checks = 0, fails = 0; };

#define CHECK(r, cond, ...) do { (r).checks++; if (!(cond)) { (r).fails++; \
    std::printf("  [FAIL] "); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

inline bool wait_done(Platform& p, int max_polls = 5000) {
  for (int i = 0; i < max_polls; i++)
    if (!(p.reg_read(REG_STATUS) & ST_BUSY)) return true;
  return false;
}

inline void dma(Platform& p, uint32_t src, uint32_t dst, uint32_t len, bool irq_en) {
  p.reg_write(REG_SRC, src);
  p.reg_write(REG_DST, dst);
  p.reg_write(REG_LEN, len);
  p.reg_write(REG_CTRL, CTRL_START | (irq_en ? CTRL_IRQ_EN : 0));
}

inline uint32_t pat(uint32_t seed, uint32_t i) { return seed ^ (i * 0x9E3779B1u); }

inline void test_basic(Platform& p, Result& r) {
  p.reset();
  for (uint32_t i = 0; i < 16; i++) p.mem_write(0x100 + 4 * i, pat(0xA5A50000, i));
  dma(p, 0x100, 0x400, 16, false);
  CHECK(r, wait_done(p), "basic: timeout");
  uint32_t st = p.reg_read(REG_STATUS);
  CHECK(r, (st & ST_DONE) && !(st & ST_ERR) && !(st & ST_BUSY), "basic: status %x", st);
  for (uint32_t i = 0; i < 16; i++)
    CHECK(r, p.mem_read(0x400 + 4 * i) == pat(0xA5A50000, i), "basic: word %u", i);
  CHECK(r, !p.irq(), "basic: irq must be low when disabled");
}

inline void test_irq(Platform& p, Result& r) {
  p.reset();
  for (uint32_t i = 0; i < 4; i++) p.mem_write(0x200 + 4 * i, pat(0x1234, i));
  dma(p, 0x200, 0x600, 4, true);
  CHECK(r, wait_done(p), "irq: timeout");
  CHECK(r, p.irq(), "irq: not asserted");
  p.reg_write(REG_CLEAR, 1);
  p.tick(2);
  CHECK(r, !p.irq(), "irq: not cleared");
  CHECK(r, !(p.reg_read(REG_STATUS) & ST_DONE), "irq: DONE not cleared");
}

inline void test_errors(Platform& p, Result& r) {
  p.reset();
  p.mem_write(0x800, 0xDEADBEEF);
  struct Case { uint32_t src, dst, len; const char* why; } cases[] = {
    {0x100, 0x800, 0, "zero length"},
    {0x101, 0x800, 4, "unaligned src"},
    {0x100, 0x802, 4, "unaligned dst"},
    {0x100, 0xFF8, 4, "dst out of range"},
    {0xFF8, 0x100, 4, "src out of range"},
    {0x100, 0x800, 0xFFFFFFFFu, "huge length"},
  };
  for (auto& c : cases) {
    dma(p, c.src, c.dst, c.len, false);
    p.tick(3);
    uint32_t st = p.reg_read(REG_STATUS);
    CHECK(r, (st & ST_ERR) && !(st & ST_DONE) && !(st & ST_BUSY), "errors: %s -> status %x", c.why, st);
    p.reg_write(REG_CLEAR, 2);
  }
  CHECK(r, p.mem_read(0x800) == 0xDEADBEEF, "errors: memory modified by rejected transfer");
  CHECK(r, p.reg_read(REG_STATUS) == 0, "errors: ERR not cleared");
}

inline void test_random(Platform& p, Result& r, int iters, uint32_t seed) {
  p.reset();
  std::mt19937 rng(seed);
  for (int it = 0; it < iters; it++) {
    uint32_t len = 1 + rng() % 64, src = 4 * (rng() % 401), dst = 4 * (500 + rng() % 401), s = rng();
    for (uint32_t i = 0; i < len; i++) p.mem_write(src + 4 * i, pat(s, i));
    dma(p, src, dst, len, it & 1);
    CHECK(r, wait_done(p), "random %d: timeout", it);
    if (it & 1) CHECK(r, p.irq(), "random %d: irq", it);
    p.reg_write(REG_CLEAR, 3);
    for (uint32_t i = 0; i < len; i++)
      CHECK(r, p.mem_read(dst + 4 * i) == pat(s, i), "random %d: word %u", it, i);
  }
}

inline int run_all(Platform& p) {
  Result r;
  std::printf("== running on %s ==\n", p.name());
  test_basic(p, r);
  test_irq(p, r);
  test_errors(p, r);
  test_random(p, r, 100, 1234);
  std::printf("   checks: %d  failures: %d  -> %s\n", r.checks, r.fails, r.fails ? "FAIL" : "PASS");
  return r.fails;
}
