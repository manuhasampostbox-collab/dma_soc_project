// Functional C++ model of the DMA (pre-silicon "C model").
#pragma once
#include "platform.h"
#include <vector>

class ModelPlatform : public Platform {
  static constexpr uint32_t MEM_BYTES = 4096;
  std::vector<uint32_t> ram_;
  uint32_t src_ = 0, dst_ = 0, len_ = 0;
  bool irq_en_ = false, done_ = false, err_ = false;
 public:
  ModelPlatform() : ram_(MEM_BYTES / 4, 0) {}
  const char* name() const override { return "C-model"; }
  void reset() override { src_ = dst_ = len_ = 0; irq_en_ = done_ = err_ = false; }
  void reg_write(uint32_t off, uint32_t v) override {
    switch (off) {
      case REG_SRC: src_ = v; break;
      case REG_DST: dst_ = v; break;
      case REG_LEN: len_ = v; break;
      case REG_CTRL:
        irq_en_ = v & CTRL_IRQ_EN;
        if (v & CTRL_START) start();
        break;
      case REG_CLEAR:
        if (v & 1) done_ = false;
        if (v & 2) err_ = false;
        break;
    }
  }
  uint32_t reg_read(uint32_t off) override {
    switch (off) {
      case REG_SRC: return src_;
      case REG_DST: return dst_;
      case REG_LEN: return len_;
      case REG_CTRL: return irq_en_ ? CTRL_IRQ_EN : 0;
      case REG_STATUS: return (err_ ? ST_ERR : 0) | (done_ ? ST_DONE : 0);  // never busy: instant
    }
    return 0;
  }
  void mem_write(uint32_t a, uint32_t v) override { ram_[(a / 4) % ram_.size()] = v; }
  uint32_t mem_read(uint32_t a) override { return ram_[(a / 4) % ram_.size()]; }
  bool irq() override { return done_ && irq_en_; }
  void tick(int) override {}
 private:
  void start() {
    done_ = err_ = false;
    uint64_t se = (uint64_t)src_ + 4ull * len_, de = (uint64_t)dst_ + 4ull * len_;
    if (len_ == 0 || (src_ & 3) || (dst_ & 3) || se > MEM_BYTES || de > MEM_BYTES) {
      err_ = true;
      return;
    }
    for (uint32_t i = 0; i < len_; i++) ram_[dst_ / 4 + i] = ram_[src_ / 4 + i];
    done_ = true;
  }
};
