// Drives the Verilated RTL (dma_soc) through its APB port.
#pragma once
#include "platform.h"
#include "Vdma_soc.h"
#include "verilated.h"

class RtlPlatform : public Platform {
  Vdma_soc* d_;
  void half() { d_->eval(); }
  void clock() { d_->clk = 0; d_->eval(); d_->clk = 1; d_->eval(); }
 public:
  RtlPlatform() : d_(new Vdma_soc) {
    d_->clk = 0; d_->psel = d_->penable = d_->pwrite = 0; d_->bd_we = 0;
    d_->rst_n = 0; d_->eval();
    reset();
  }
  ~RtlPlatform() override { d_->final(); delete d_; }
  const char* name() const override { return "RTL (Verilator)"; }
  void reset() override {
    d_->rst_n = 0; for (int i = 0; i < 3; i++) clock();
    d_->rst_n = 1; clock();
  }
  void reg_write(uint32_t off, uint32_t v) override {
    d_->psel = 1; d_->pwrite = 1; d_->paddr = off; d_->pwdata = v; d_->penable = 0; clock();
    d_->penable = 1; clock();
    d_->psel = 0; d_->penable = 0; d_->pwrite = 0; clock();
  }
  uint32_t reg_read(uint32_t off) override {
    d_->psel = 1; d_->pwrite = 0; d_->paddr = off; d_->penable = 0; clock();
    d_->penable = 1; d_->eval();
    uint32_t v = d_->prdata; clock();
    d_->psel = 0; d_->penable = 0; clock();
    return v;
  }
  void mem_write(uint32_t a, uint32_t v) override {
    d_->bd_we = 1; d_->bd_addr = a; d_->bd_wdata = v; clock(); d_->bd_we = 0;
  }
  uint32_t mem_read(uint32_t a) override { d_->bd_addr = a; d_->eval(); return d_->bd_rdata; }
  bool irq() override { d_->eval(); return d_->irq; }
  void tick(int n) override { for (int i = 0; i < n; i++) clock(); }
};
