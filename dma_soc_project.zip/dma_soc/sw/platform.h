// Test-reuse layer: the same test code runs on a C model and on the RTL.
#pragma once
#include <cstdint>

// Register offsets (must match rtl/dma_ctrl.sv)
enum : uint32_t {
  REG_SRC = 0x00, REG_DST = 0x04, REG_LEN = 0x08,
  REG_CTRL = 0x0C, REG_STATUS = 0x10, REG_CLEAR = 0x14,
};
enum : uint32_t { CTRL_START = 1u << 0, CTRL_IRQ_EN = 1u << 1 };
enum : uint32_t { ST_BUSY = 1u << 0, ST_DONE = 1u << 1, ST_ERR = 1u << 2 };

class Platform {
 public:
  virtual ~Platform() = default;
  virtual const char* name() const = 0;
  virtual void     reg_write(uint32_t off, uint32_t val) = 0;
  virtual uint32_t reg_read(uint32_t off) = 0;
  virtual void     mem_write(uint32_t addr, uint32_t val) = 0;  // backdoor
  virtual uint32_t mem_read(uint32_t addr) = 0;                 // backdoor
  virtual bool     irq() = 0;
  virtual void     tick(int cycles) = 0;                        // let time pass
  virtual void     reset() = 0;
};
