#include "model_platform.h"
#include "rtl_platform.h"
#include "tests.h"
#include <memory>

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  int fails = 0;
  { ModelPlatform m; fails += run_all(m); }
  { RtlPlatform   r; fails += run_all(r); }
  std::printf("\nOVERALL: %s\n", fails ? "FAIL" : "PASS");
  return fails ? 1 : 0;
}
