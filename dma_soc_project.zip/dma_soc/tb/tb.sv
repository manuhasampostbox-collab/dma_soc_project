// Self-checking SystemVerilog testbench for dma_soc (directed + constrained-random).
`timescale 1ns/1ps
module tb;
  logic clk = 0, rst_n = 0;
  logic psel = 0, penable = 0, pwrite = 0;
  logic [7:0]  paddr = 0;
  logic [31:0] pwdata = 0, prdata;
  logic pready, irq;
  logic bd_we = 0;
  logic [31:0] bd_addr = 0, bd_wdata = 0, bd_rdata;

  dma_soc dut (.*);

  always #5 clk = ~clk;

  int errors = 0;
  int checks = 0;

  // ---------------- helpers ----------------
  task automatic check(input bit cond, input string msg);
    checks++;
    if (!cond) begin errors++; $display("[FAIL] %s", msg); end
  endtask

  task automatic apb_write(input logic [7:0] a, input logic [31:0] d);
    @(posedge clk); psel <= 1; pwrite <= 1; paddr <= a; pwdata <= d; penable <= 0;
    @(posedge clk); penable <= 1;
    @(posedge clk); psel <= 0; penable <= 0; pwrite <= 0;
  endtask

  task automatic apb_read(input logic [7:0] a, output logic [31:0] d);
    @(posedge clk); psel <= 1; pwrite <= 0; paddr <= a; penable <= 0;
    @(posedge clk); penable <= 1;
    @(posedge clk); d = prdata; psel <= 0; penable <= 0;
  endtask

  task automatic mem_w(input int unsigned byte_addr, input logic [31:0] d);
    @(posedge clk); bd_we <= 1; bd_addr <= byte_addr; bd_wdata <= d;
    @(posedge clk); bd_we <= 0;
  endtask

  task automatic mem_r(input int unsigned byte_addr, output logic [31:0] d);
    bd_addr = byte_addr; #1; d = bd_rdata;
  endtask

  task automatic wait_done(output bit timed_out);
    logic [31:0] st; int n = 0;
    timed_out = 0;
    do begin
      apb_read(8'h10, st); n++;
      if (n > 2000) begin timed_out = 1; return; end
    end while (st[0]);
  endtask

  task automatic start_dma(input int unsigned src, input int unsigned dst,
                           input int unsigned len, input bit irq_en);
    apb_write(8'h00, src);
    apb_write(8'h04, dst);
    apb_write(8'h08, len);
    apb_write(8'h0C, {30'b0, irq_en, 1'b1});
  endtask

  task automatic fill(input int unsigned base, input int unsigned len, input int unsigned seed);
    for (int i = 0; i < len; i++) mem_w(base + 4*i, seed ^ (i * 32'h9E3779B1));
  endtask

  task automatic check_copy(input int unsigned src, input int unsigned dst,
                            input int unsigned len, input int unsigned seed, input string tag);
    logic [31:0] got;
    for (int i = 0; i < len; i++) begin
      mem_r(dst + 4*i, got);
      check(got == (seed ^ (i * 32'h9E3779B1)),
            $sformatf("%s: word %0d expected %08x got %08x", tag, i, seed ^ (i * 32'h9E3779B1), got));
    end
  endtask

  // ---------------- assertions ----------------
  // memory port never addresses outside the RAM
  a_mem_range: assert property (@(posedge clk) disable iff (!rst_n)
                  dut.mem_en |-> dut.mem_addr < 4096)
    else begin errors++; $display("[FAIL] memory address out of range"); end
  // irq equals DONE & IRQ_EN
  a_irq: assert property (@(posedge clk) disable iff (!rst_n)
                  irq == (dut.u_dma.done_q & dut.u_dma.irq_en_q))
    else begin errors++; $display("[FAIL] irq mismatch"); end

  // ---------------- tests ----------------
  logic [31:0] st, rd;
  bit to;

  task automatic test_reset_values();
    $display("test_reset_values");
    apb_read(8'h10, st); check(st == 0, "STATUS resets to 0");
    apb_read(8'h08, rd); check(rd == 0, "LEN resets to 0");
    check(irq == 0, "irq low mem_post reset");
  endtask

  task automatic test_basic();
    $display("test_basic");
    fill(32'h100, 16, 32'hA5A50000);
    start_dma(32'h100, 32'h400, 16, 0);
    wait_done(to); check(!to, "basic: no timeout");
    apb_read(8'h10, st); check(st[1] && !st[0] && !st[2], "basic: DONE set, BUSY/ERR clear");
    check_copy(32'h100, 32'h400, 16, 32'hA5A50000, "basic");
    check(irq == 0, "basic: irq low when IRQ_EN=0");
  endtask

  task automatic test_irq();
    $display("test_irq");
    apb_write(8'h14, 3);
    fill(32'h200, 4, 32'h1234);
    start_dma(32'h200, 32'h600, 4, 1);
    wait_done(to);
    check(irq == 1, "irq: asserted on completion");
    apb_write(8'h14, 1);
    @(posedge clk); #1;
    check(irq == 0, "irq: cleared by W1C DONE");
    apb_read(8'h10, st); check(!st[1], "irq: DONE cleared");
    check_copy(32'h200, 32'h600, 4, 32'h1234, "irq");
    apb_write(8'h0C, 0);
  endtask

  task automatic test_errors();
    logic [31:0] mem_pre, mem_post;
    $display("test_errors");
    mem_w(32'h800, 32'hDEADBEEF);
    mem_r(32'h800, mem_pre);
    // zero length
    apb_write(8'h00, 32'h100); apb_write(8'h04, 32'h800); apb_write(8'h08, 0); apb_write(8'h0C, 1);
    @(posedge clk); @(posedge clk);
    apb_read(8'h10, st); check(st[2] && !st[1] && !st[0], "err: zero length sets ERR");
    apb_write(8'h14, 2);
    // unaligned source
    start_dma(32'h101, 32'h800, 4, 0);
    @(posedge clk); @(posedge clk);
    apb_read(8'h10, st); check(st[2], "err: unaligned src sets ERR");
    apb_write(8'h14, 2);
    // unaligned destination
    start_dma(32'h100, 32'h802, 4, 0);
    @(posedge clk); @(posedge clk);
    apb_read(8'h10, st); check(st[2], "err: unaligned dst sets ERR");
    apb_write(8'h14, 2);
    // out of range (would run past 4096 bytes)
    start_dma(32'h100, 32'hFF8, 4, 0);
    @(posedge clk); @(posedge clk);
    apb_read(8'h10, st); check(st[2], "err: out of range sets ERR");
    apb_write(8'h14, 2);
    // huge length must not overflow the range check
    start_dma(32'h100, 32'h800, 32'hFFFF_FFFF, 0);
    @(posedge clk); @(posedge clk);
    apb_read(8'h10, st); check(st[2], "err: huge length sets ERR");
    apb_write(8'h14, 2);
    mem_r(32'h800, mem_post);
    check(mem_post == mem_pre, "err: memory untouched by rejected transfers");
    apb_read(8'h10, st); check(st == 0, "err: ERR cleared by W1C");
  endtask

  task automatic test_start_while_busy();
    $display("test_start_while_busy");
    fill(32'h300, 32, 32'h77770000);
    start_dma(32'h300, 32'h700, 32, 0);
    // poke the config and START again while busy: must be ignored
    apb_write(8'h08, 2);
    apb_write(8'h0C, 1);
    wait_done(to); check(!to, "busy: no timeout");
    check_copy(32'h300, 32'h700, 32, 32'h77770000, "busy");
  endtask

  task automatic test_random(input int iterations);
    int unsigned len, src, dst, seed;
    $display("test_random (%0d iterations)", iterations);
    for (int it = 0; it < iterations; it++) begin
      len = $urandom_range(1, 64);
      // two disjoint regions inside the 1024-word RAM
      src = 4 * $urandom_range(0, 400);
      dst = 4 * $urandom_range(500, 900);
      seed = $urandom;
      fill(src, len, seed);
      start_dma(src, dst, len, it[0]);
      wait_done(to);
      check(!to, $sformatf("random %0d: no timeout", it));
      if (it[0]) check(irq == 1, $sformatf("random %0d: irq", it));
      apb_write(8'h14, 3);
      check_copy(src, dst, len, seed, $sformatf("random %0d", it));
    end
  endtask

  initial begin
    repeat (4) @(posedge clk);
    rst_n = 1;
    repeat (2) @(posedge clk);
    test_reset_values();
    test_basic();
    test_irq();
    test_errors();
    test_start_while_busy();
    test_random(100);
    $display("----------------------------------------");
    $display("checks: %0d  errors: %0d", checks, errors);
    if (errors == 0) $display("RESULT: PASS"); else $display("RESULT: FAIL");
    $finish;
  end

  initial begin #50_000_000; $display("RESULT: FAIL (global timeout)"); $finish; end
endmodule
