# dma_soc: DMA controller with SystemVerilog testbench and C-model/RTL test reuse

A small pre-silicon style project: a memory-to-memory DMA controller with an APB register
interface, verified two ways.

## What is in it
- `rtl/dma_ctrl.sv`: DMA controller (SRC, DST, LEN, CTRL, STATUS, CLEAR registers, IRQ output,
  error checks for zero length, unaligned addresses, and out-of-range transfers).
- `rtl/dma_soc.sv`: DMA plus 4 KB RAM with a backdoor port for tests.
- `tb/tb.sv`: self-checking SystemVerilog testbench: directed tests, 100 randomized transfers,
  and concurrent assertions (memory address range, irq == DONE & IRQ_EN).
- `sw/`: C++ test framework. The tests in `sw/tests.h` are written once against a `Platform`
  interface and run unchanged on (1) a C++ functional model and (2) the Verilated RTL driven
  through its APB port. This is the "test re-use across platforms" idea.

## Run
    pip install verilator        # needs g++ and make
    make all                     # SV testbench, then C-model + RTL tests

Expected: `RESULT: PASS` from the SV testbench, and PASS on both platforms in the C++ run.

## Bug found by the tests
The first version of the range check used 34 bits, so `addr + len*4` overflowed for
`len = 0xFFFFFFFF` and the transfer was wrongly accepted. Fixed by widening to 35 bits.

## Limits (be honest about these)
Not UVM; no real SoC, MMU, or IOMMU; the memory port is simple; run on Verilator only;
no FPGA or silicon run.
